package org.nustaq.serialization;

/**
 * Created by ruedi on 31.03.14.
 */
public interface FSTCrossPlatformSerialzer extends FSTObjectSerializer {

    boolean writeTupleEnd();

}
